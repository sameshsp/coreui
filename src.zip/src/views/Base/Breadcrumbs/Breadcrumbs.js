import React, { Component } from "react";
import {
  Breadcrumb,
  BreadcrumbItem,
  Card,
  CardBody,
  CardHeader,
  Col,
  Row,
} from "reactstrap";

import { Link } from "react-router-dom";
import TutorialDataService from "./services/tutorial.service";

class Breadcrumbs extends Component {
  constructor(props) {
    super(props);
    this.onChangeSearchTitle = this.onChangeSearchTitle.bind(this);
    this.retrieveTutorials = this.retrieveTutorials.bind(this);
    this.refreshList = this.refreshList.bind(this);
    this.setActiveTutorial = this.setActiveTutorial.bind(this);
    this.removeAllTutorials = this.removeAllTutorials.bind(this);
    this.searchTitle = this.searchTitle.bind(this);

    this.state = {
      tutorials: [],
      currentTutorial: null,
      currentIndex: -1,
      searchTitle: "",
    };
  }

  componentDidMount() {
    this.retrieveTutorials();
  }

  onChangeSearchTitle(e) {
    const searchTitle = e.target.value;

    this.setState({
      searchTitle: searchTitle,
    });
  }

  retrieveTutorials() {
    TutorialDataService.getAll()
      .then((response) => {
        this.setState({
          tutorials: response.data,
        });
        console.log(response.data);
      })
      .catch((e) => {
        console.log(e);
      });
  }

  refreshList() {
    this.retrieveTutorials();
    this.setState({
      currentTutorial: null,
      currentIndex: -1,
    });
  }

  setActiveTutorial(tutorial, index) {
    this.setState({
      currentTutorial: tutorial,
      currentIndex: index,
    });
  }

  removeAllTutorials() {
    TutorialDataService.deleteAll()
      .then((response) => {
        console.log(response.data);
        this.refreshList();
      })
      .catch((e) => {
        console.log(e);
      });
  }

  searchTitle() {
    TutorialDataService.findByTitle(this.state.searchTitle)
      .then((response) => {
        this.setState({
          tutorials: response.data,
        });
        console.log(response.data);
      })
      .catch((e) => {
        console.log(e);
      });
  }

  render() {
    const {
      searchTitle,
      tutorials,
      currentTutorial,
      currentIndex,
    } = this.state;

    return (
      <div className="animated fadeIn">
        <Row>
          <Col xs="12">
            <Card>
              <CardHeader>
                <i className="fa fa-align-justify"></i>
                <strong>Tutorials</strong>
                <div className="card-header-actions">
                  <a
                    href="https://reactstrap.github.io/components/breadcrumbs/"
                    rel="noreferrer noopener"
                    target="_blank"
                    className="card-header-action"
                  >
                    <small className="text-muted">docs</small>
                  </a>
                </div>
              </CardHeader>
              <CardBody>
                <div className="list row">
                  <div className="col-md-8">
                    <div className="input-group mb-3">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Search by title"
                        value={searchTitle}
                        onChange={this.onChangeSearchTitle}
                      />
                      <div className="input-group-append">
                        <button
                          className="btn btn-outline-secondary"
                          type="button"
                          onClick={this.searchTitle}
                        >
                          Search
                        </button>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <h4>Tutorials List</h4>

                    <ul className="list-group">
                      {tutorials &&
                        tutorials.map((tutorial, index) => (
                          <li
                            className={
                              "list-group-item " +
                              (index === currentIndex ? "active" : "")
                            }
                            onClick={() =>
                              this.setActiveTutorial(tutorial, index)
                            }
                            key={index}
                          >
                            {tutorial.title}
                          </li>
                        ))}
                    </ul>

                    <button
                      className="m-3 btn btn-sm btn-danger"
                      onClick={this.removeAllTutorials}
                    >
                      Remove All
                    </button>
                  </div>
                  <div className="col-md-6">
                    {currentTutorial ? (
                      <div>
                        <h4>Tutorial</h4>
                        <div>
                          <label>
                            <strong>Title:</strong>
                          </label>{" "}
                          {currentTutorial.title}
                        </div>
                        <div>
                          <label>
                            <strong>Description:</strong>
                          </label>{" "}
                          {currentTutorial.body}
                        </div>
                        <div>
                          <label>
                            <strong>Status:</strong>
                          </label>{" "}
                          {currentTutorial.userId ? "active" : "Inactive"}
                        </div>

                        <Link
                          to={"/base/jumbotrons/" + currentTutorial.id}
                          className="badge badge-warning"
                        >
                          Edit
                        </Link>
                      </div>
                    ) : (
                      <div>
                        <br />
                        <p>Please click on a Tutorial...</p>
                      </div>
                    )}
                  </div>
                </div>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
    );
  }
}

export default Breadcrumbs;
