import React, { Component } from 'react'

export default class Tutorial extends Component {
    render() {
        return (
            <div>
                Tutorial
            </div>
        )
    }
}
